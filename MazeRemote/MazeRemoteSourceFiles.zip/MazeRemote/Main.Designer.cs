﻿namespace MazeRemote
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ConnectButton = new System.Windows.Forms.Button();
            this.portTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.forwardButton = new System.Windows.Forms.Button();
            this.strafeRightButton = new System.Windows.Forms.Button();
            this.strafeLeftButton = new System.Windows.Forms.Button();
            this.backwardButton = new System.Windows.Forms.Button();
            this.turnRightButton = new System.Windows.Forms.Button();
            this.turnLeftButton = new System.Windows.Forms.Button();
            this.jumpButton = new System.Windows.Forms.Button();
            this.stepsizeText = new System.Windows.Forms.TextBox();
            this.turnSizeText = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.messageText = new System.Windows.Forms.TextBox();
            this.messageButton = new System.Windows.Forms.Button();
            this.cueButton = new System.Windows.Forms.Button();
            this.setPositionButton = new System.Windows.Forms.Button();
            this.xTextBox = new System.Windows.Forms.TextBox();
            this.yTextBox = new System.Windows.Forms.TextBox();
            this.zTextBox = new System.Windows.Forms.TextBox();
            this.angleTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.getPositionButton = new System.Windows.Forms.Button();
            this.updateText = new System.Windows.Forms.Label();
            this.nextButton = new System.Windows.Forms.Button();
            this.boundedCheck = new System.Windows.Forms.CheckBox();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ConnectButton
            // 
            this.ConnectButton.Location = new System.Drawing.Point(231, 12);
            this.ConnectButton.Margin = new System.Windows.Forms.Padding(4);
            this.ConnectButton.Name = "ConnectButton";
            this.ConnectButton.Size = new System.Drawing.Size(100, 28);
            this.ConnectButton.TabIndex = 0;
            this.ConnectButton.Text = "Start";
            this.ConnectButton.UseVisualStyleBackColor = true;
            this.ConnectButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // portTextBox
            // 
            this.portTextBox.Location = new System.Drawing.Point(137, 15);
            this.portTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.portTextBox.Name = "portTextBox";
            this.portTextBox.Size = new System.Drawing.Size(67, 22);
            this.portTextBox.TabIndex = 1;
            this.portTextBox.Text = "6350";
            this.portTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 18);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Port Number";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 414);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(580, 25);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(365, 20);
            this.toolStripStatusLabel1.Text = "Press Start to listen for connection from MazeWalker...";
            // 
            // forwardButton
            // 
            this.forwardButton.Location = new System.Drawing.Point(164, 123);
            this.forwardButton.Margin = new System.Windows.Forms.Padding(4);
            this.forwardButton.Name = "forwardButton";
            this.forwardButton.Size = new System.Drawing.Size(83, 66);
            this.forwardButton.TabIndex = 4;
            this.forwardButton.Text = "^";
            this.forwardButton.UseVisualStyleBackColor = true;
            this.forwardButton.Click += new System.EventHandler(this.forwardButton_Click);
            // 
            // strafeRightButton
            // 
            this.strafeRightButton.Location = new System.Drawing.Point(255, 197);
            this.strafeRightButton.Margin = new System.Windows.Forms.Padding(4);
            this.strafeRightButton.Name = "strafeRightButton";
            this.strafeRightButton.Size = new System.Drawing.Size(83, 66);
            this.strafeRightButton.TabIndex = 5;
            this.strafeRightButton.Text = ">";
            this.strafeRightButton.UseVisualStyleBackColor = true;
            this.strafeRightButton.Click += new System.EventHandler(this.strafeRightButton_Click);
            // 
            // strafeLeftButton
            // 
            this.strafeLeftButton.Location = new System.Drawing.Point(73, 197);
            this.strafeLeftButton.Margin = new System.Windows.Forms.Padding(4);
            this.strafeLeftButton.Name = "strafeLeftButton";
            this.strafeLeftButton.Size = new System.Drawing.Size(83, 66);
            this.strafeLeftButton.TabIndex = 6;
            this.strafeLeftButton.Text = "<";
            this.strafeLeftButton.UseVisualStyleBackColor = true;
            this.strafeLeftButton.Click += new System.EventHandler(this.strafeLeftButton_Click);
            // 
            // backwardButton
            // 
            this.backwardButton.Location = new System.Drawing.Point(164, 271);
            this.backwardButton.Margin = new System.Windows.Forms.Padding(4);
            this.backwardButton.Name = "backwardButton";
            this.backwardButton.Size = new System.Drawing.Size(83, 66);
            this.backwardButton.TabIndex = 7;
            this.backwardButton.Text = "V";
            this.backwardButton.UseVisualStyleBackColor = true;
            this.backwardButton.Click += new System.EventHandler(this.backwardButton_Click);
            // 
            // turnRightButton
            // 
            this.turnRightButton.Location = new System.Drawing.Point(255, 123);
            this.turnRightButton.Margin = new System.Windows.Forms.Padding(4);
            this.turnRightButton.Name = "turnRightButton";
            this.turnRightButton.Size = new System.Drawing.Size(83, 66);
            this.turnRightButton.TabIndex = 8;
            this.turnRightButton.Text = "Turn Right";
            this.turnRightButton.UseVisualStyleBackColor = true;
            this.turnRightButton.Click += new System.EventHandler(this.turnRightButton_Click);
            // 
            // turnLeftButton
            // 
            this.turnLeftButton.Location = new System.Drawing.Point(73, 123);
            this.turnLeftButton.Margin = new System.Windows.Forms.Padding(4);
            this.turnLeftButton.Name = "turnLeftButton";
            this.turnLeftButton.Size = new System.Drawing.Size(83, 66);
            this.turnLeftButton.TabIndex = 9;
            this.turnLeftButton.Text = "Turn Left";
            this.turnLeftButton.UseVisualStyleBackColor = true;
            this.turnLeftButton.Click += new System.EventHandler(this.turnLeftButton_Click);
            // 
            // jumpButton
            // 
            this.jumpButton.Location = new System.Drawing.Point(164, 197);
            this.jumpButton.Margin = new System.Windows.Forms.Padding(4);
            this.jumpButton.Name = "jumpButton";
            this.jumpButton.Size = new System.Drawing.Size(83, 66);
            this.jumpButton.TabIndex = 10;
            this.jumpButton.Text = "Jump";
            this.jumpButton.UseVisualStyleBackColor = true;
            this.jumpButton.Click += new System.EventHandler(this.jumpButton_Click);
            // 
            // stepsizeText
            // 
            this.stepsizeText.Location = new System.Drawing.Point(496, 300);
            this.stepsizeText.Margin = new System.Windows.Forms.Padding(4);
            this.stepsizeText.Name = "stepsizeText";
            this.stepsizeText.Size = new System.Drawing.Size(73, 22);
            this.stepsizeText.TabIndex = 11;
            this.stepsizeText.Text = "5";
            // 
            // turnSizeText
            // 
            this.turnSizeText.Location = new System.Drawing.Point(496, 332);
            this.turnSizeText.Margin = new System.Windows.Forms.Padding(4);
            this.turnSizeText.Name = "turnSizeText";
            this.turnSizeText.Size = new System.Drawing.Size(73, 22);
            this.turnSizeText.TabIndex = 12;
            this.turnSizeText.Text = "90";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(356, 303);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 17);
            this.label2.TabIndex = 13;
            this.label2.Text = "Step Size (mz units)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(356, 335);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 17);
            this.label3.TabIndex = 14;
            this.label3.Text = "Turn Size (degrees)";
            // 
            // messageText
            // 
            this.messageText.Location = new System.Drawing.Point(23, 377);
            this.messageText.Margin = new System.Windows.Forms.Padding(4);
            this.messageText.Name = "messageText";
            this.messageText.Size = new System.Drawing.Size(416, 22);
            this.messageText.TabIndex = 15;
            // 
            // messageButton
            // 
            this.messageButton.Location = new System.Drawing.Point(445, 374);
            this.messageButton.Margin = new System.Windows.Forms.Padding(4);
            this.messageButton.Name = "messageButton";
            this.messageButton.Size = new System.Drawing.Size(124, 28);
            this.messageButton.TabIndex = 16;
            this.messageButton.Text = "Send Message";
            this.messageButton.UseVisualStyleBackColor = true;
            this.messageButton.Click += new System.EventHandler(this.messageButton_Click);
            // 
            // cueButton
            // 
            this.cueButton.Location = new System.Drawing.Point(144, 75);
            this.cueButton.Margin = new System.Windows.Forms.Padding(4);
            this.cueButton.Name = "cueButton";
            this.cueButton.Size = new System.Drawing.Size(133, 28);
            this.cueButton.TabIndex = 17;
            this.cueButton.Text = "Send Start Cue";
            this.cueButton.UseVisualStyleBackColor = true;
            this.cueButton.Click += new System.EventHandler(this.cueButton_Click);
            // 
            // setPositionButton
            // 
            this.setPositionButton.Location = new System.Drawing.Point(471, 197);
            this.setPositionButton.Margin = new System.Windows.Forms.Padding(4);
            this.setPositionButton.Name = "setPositionButton";
            this.setPositionButton.Size = new System.Drawing.Size(100, 28);
            this.setPositionButton.TabIndex = 18;
            this.setPositionButton.Text = "SetPosition";
            this.setPositionButton.UseVisualStyleBackColor = true;
            this.setPositionButton.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // xTextBox
            // 
            this.xTextBox.Location = new System.Drawing.Point(471, 64);
            this.xTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.xTextBox.MaxLength = 10;
            this.xTextBox.Name = "xTextBox";
            this.xTextBox.Size = new System.Drawing.Size(99, 22);
            this.xTextBox.TabIndex = 19;
            this.xTextBox.Text = "0";
            // 
            // yTextBox
            // 
            this.yTextBox.Location = new System.Drawing.Point(471, 96);
            this.yTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.yTextBox.MaxLength = 10;
            this.yTextBox.Name = "yTextBox";
            this.yTextBox.Size = new System.Drawing.Size(99, 22);
            this.yTextBox.TabIndex = 20;
            this.yTextBox.Text = "0";
            // 
            // zTextBox
            // 
            this.zTextBox.Location = new System.Drawing.Point(471, 128);
            this.zTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.zTextBox.MaxLength = 10;
            this.zTextBox.Name = "zTextBox";
            this.zTextBox.Size = new System.Drawing.Size(99, 22);
            this.zTextBox.TabIndex = 21;
            this.zTextBox.Text = "0";
            // 
            // angleTextBox
            // 
            this.angleTextBox.Location = new System.Drawing.Point(471, 165);
            this.angleTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.angleTextBox.MaxLength = 10;
            this.angleTextBox.Name = "angleTextBox";
            this.angleTextBox.Size = new System.Drawing.Size(99, 22);
            this.angleTextBox.TabIndex = 22;
            this.angleTextBox.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(428, 68);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 17);
            this.label4.TabIndex = 23;
            this.label4.Text = "X:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(428, 100);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 17);
            this.label5.TabIndex = 24;
            this.label5.Text = "Y:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(428, 132);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 17);
            this.label6.TabIndex = 25;
            this.label6.Text = "Z:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(405, 169);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 17);
            this.label7.TabIndex = 26;
            this.label7.Text = "Angle:";
            // 
            // getPositionButton
            // 
            this.getPositionButton.Location = new System.Drawing.Point(471, 233);
            this.getPositionButton.Margin = new System.Windows.Forms.Padding(4);
            this.getPositionButton.Name = "getPositionButton";
            this.getPositionButton.Size = new System.Drawing.Size(100, 28);
            this.getPositionButton.TabIndex = 27;
            this.getPositionButton.Text = "GetPosition";
            this.getPositionButton.UseVisualStyleBackColor = true;
            this.getPositionButton.Click += new System.EventHandler(this.getPositionButton_Click);
            // 
            // updateText
            // 
            this.updateText.Location = new System.Drawing.Point(359, 265);
            this.updateText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.updateText.Name = "updateText";
            this.updateText.Size = new System.Drawing.Size(212, 31);
            this.updateText.TabIndex = 28;
            this.updateText.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nextButton
            // 
            this.nextButton.Location = new System.Drawing.Point(464, 11);
            this.nextButton.Margin = new System.Windows.Forms.Padding(4);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(100, 28);
            this.nextButton.TabIndex = 29;
            this.nextButton.Text = "NextLevel";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // boundedCheck
            // 
            this.boundedCheck.AutoSize = true;
            this.boundedCheck.Location = new System.Drawing.Point(29, 348);
            this.boundedCheck.Margin = new System.Windows.Forms.Padding(4);
            this.boundedCheck.Name = "boundedCheck";
            this.boundedCheck.Size = new System.Drawing.Size(153, 21);
            this.boundedCheck.TabIndex = 30;
            this.boundedCheck.Text = "Block Invalid Moves";
            this.boundedCheck.UseVisualStyleBackColor = true;
            this.boundedCheck.CheckedChanged += new System.EventHandler(this.boundedCheck_CheckedChanged);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 439);
            this.Controls.Add(this.boundedCheck);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.updateText);
            this.Controls.Add(this.getPositionButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.angleTextBox);
            this.Controls.Add(this.zTextBox);
            this.Controls.Add(this.yTextBox);
            this.Controls.Add(this.xTextBox);
            this.Controls.Add(this.setPositionButton);
            this.Controls.Add(this.cueButton);
            this.Controls.Add(this.messageButton);
            this.Controls.Add(this.messageText);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.turnSizeText);
            this.Controls.Add(this.stepsizeText);
            this.Controls.Add(this.jumpButton);
            this.Controls.Add(this.turnLeftButton);
            this.Controls.Add(this.turnRightButton);
            this.Controls.Add(this.backwardButton);
            this.Controls.Add(this.strafeLeftButton);
            this.Controls.Add(this.strafeRightButton);
            this.Controls.Add(this.forwardButton);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.portTextBox);
            this.Controls.Add(this.ConnectButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MazeRemote";
            this.Load += new System.EventHandler(this.Main_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ConnectButton;
        private System.Windows.Forms.TextBox portTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Button forwardButton;
        private System.Windows.Forms.Button strafeRightButton;
        private System.Windows.Forms.Button strafeLeftButton;
        private System.Windows.Forms.Button backwardButton;
        private System.Windows.Forms.Button turnRightButton;
        private System.Windows.Forms.Button turnLeftButton;
        private System.Windows.Forms.Button jumpButton;
        private System.Windows.Forms.TextBox stepsizeText;
        private System.Windows.Forms.TextBox turnSizeText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox messageText;
        private System.Windows.Forms.Button messageButton;
        private System.Windows.Forms.Button cueButton;
        private System.Windows.Forms.Button setPositionButton;
        private System.Windows.Forms.TextBox xTextBox;
        private System.Windows.Forms.TextBox yTextBox;
        private System.Windows.Forms.TextBox zTextBox;
        private System.Windows.Forms.TextBox angleTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button getPositionButton;
        private System.Windows.Forms.Label updateText;
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.CheckBox boundedCheck;
    }
}

